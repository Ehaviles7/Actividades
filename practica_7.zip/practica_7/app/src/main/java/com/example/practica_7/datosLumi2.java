package com.example.practica_7;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class datosLumi2 extends AppCompatActivity {

    //Declarar los objetos en la clase
    Sensor lumiSensor;
    SensorManager adminSensor;
    SensorEventListener escuchaSenso;

    Button Valor2, Resultados;

    Float valorSensor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_datos_lumi2);

        //Referenciar los objetos
        Valor2 = findViewById(R.id.btValor2);
        Resultados = findViewById(R.id.btResultado);

        Resultados.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                enviarWhatsapp();
            }
        });

        //Inicializar los servicios del sensor
        adminSensor = (SensorManager) getSystemService(SENSOR_SERVICE);

        //Definir el Sensor a utilizar
        lumiSensor = adminSensor.getDefaultSensor(Sensor.TYPE_LIGHT);

        //Validacion de existencia del sensor
        if (lumiSensor == null){
            Toast.makeText(datosLumi2.this,"No se detecto el sensor de luminosidad", Toast.LENGTH_LONG).show();
        }else {
            Toast.makeText(datosLumi2.this,"Sensor de luz detectado", Toast.LENGTH_LONG).show();

        }

        //Configurando el disparador
        escuchaSenso = new SensorEventListener() {
            @Override
            public void onSensorChanged(SensorEvent sensorEvent) {
                valorSensor = sensorEvent.values[0];
                if (sensorEvent.values[0] < lumiSensor.getMaximumRange()){
                    Valor2.setText("VALOR: " + sensorEvent.values[0] + " LUX");
                }else {
                    Valor2.setText("VALOR: " + sensorEvent.values[0] + " LUX");

                }
            }

            @Override
            public void onAccuracyChanged(Sensor sensor, int i) {

            }
        };
        iniciarSensor();
    }

    public void enviarWhatsapp(){
        try {
            Intent ventanaWhatsapp = new Intent();
            ventanaWhatsapp.setAction(Intent.ACTION_SEND);
            ventanaWhatsapp.putExtra(Intent.EXTRA_TEXT, "EL valor del sensor es : " + valorSensor);
            ventanaWhatsapp.setType("tex/plain");

            PackageManager pm = getPackageManager();
            PackageInfo info = pm.getPackageInfo("com.whatsapp", PackageManager.GET_META_DATA);

            ventanaWhatsapp.setPackage("com.whatsapp");
            startActivity(Intent.createChooser(ventanaWhatsapp, "Share with"));

            Toast.makeText(datosLumi2.this,"Me da error al querer enviar por whatsapp", Toast.LENGTH_LONG).show();

        }catch (Exception error){
            Log.e("Error", "Error al enviar " + error.getMessage());
            Toast.makeText(datosLumi2.this,"Me da error al querer enviar por whatsapp", Toast.LENGTH_LONG).show();

        }
    }

    public void iniciarSensor(){
        adminSensor.registerListener(escuchaSenso,lumiSensor,1000*1000);
    }

    public void finSenso(){
        adminSensor.unregisterListener(escuchaSenso);
    }

    @Override
    protected void onResume() {
        iniciarSensor();
        super.onResume();
    }

    @Override
    protected void onPause() {
        finSenso();
        super.onPause();
    }
}