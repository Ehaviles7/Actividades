package com.example.datospersonales;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class datos2 extends AppCompatActivity {

    //Declarar los objetos
    TextView Datos, Nomb, Carre, Cuot, Cumm, Institu, Total;
    Button Regresar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_datos2);

        //Referenciar

        Datos = findViewById(R.id.tvDatos);
        Nomb = findViewById(R.id.tvNombre);
        Carre = findViewById(R.id.tvCarrera);
        Cuot = findViewById(R.id.tvCuota);
        Cumm = findViewById(R.id.tvCum);
        Institu = findViewById(R.id.tvInstituto);
        Total = findViewById(R.id.tvPagoTotal);
        Regresar = findViewById(R.id.btRegresar);

        Regresar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();

        Bundle Dato = getIntent().getExtras();
        if (Dato != null){
            String nomb = Dato.getString("No");
            Double cumm = Dato.getDouble("Cu");
            Double cuot = Dato.getDouble("Cuo");
            String seCarre = Dato.getString("Carr");
            String seIn = Dato.getString("Ins");
            double aumento = 0;
            double total =0;
            double cumDes = 0;
            double inDes = 0;
            double descuentoTotal = 0;
            double pagoTotal = 0;



            if (seCarre.equals("Ingenieria en Manejo y Gestion de Base de Datos")){

                aumento = (cuot * 0.30) + 20;
                total = cuot + aumento;
                if (cumm > 9 && cumm <= 10){
                    cumDes = total * 0.25;
                    if (seIn.equals("Pública")){
                        inDes = total * 0.05;
                        descuentoTotal = cumDes + inDes;
                        pagoTotal = total - descuentoTotal;

                        Nomb.setText("Nombre del estudiante: " + nomb);
                        Carre.setText("Carrera seleccionada: " + seCarre);
                        Cuot.setText("Cuota estandar: $" + cuot);
                        Cumm.setText("Cum del estudiante: " + cumm);
                        Institu.setText("Tipo de institucion proveniente: " + seIn);
                        Total.setText("Cuota estandar mas aumento de 30% de carrera mas $20 por herramientas: $" + total +"\n\nDescuento de 25% por CUM de " + cumm
                        + " : $" + cumDes + "\n\nDescuento de 5% por venir de una institucion Pública: $" + inDes +"\n\nDescuento total: $" + descuentoTotal
                        + "\n\nTotal a pagar: $" + pagoTotal);

                    } else if (seIn.equals("Privada")) {
                        inDes = total * 0.1;
                        descuentoTotal = cumDes + inDes;
                        pagoTotal = total - descuentoTotal;

                        Nomb.setText("Nombre del estudiante: " + nomb);
                        Carre.setText("Carrera seleccionada: " + seCarre);
                        Cuot.setText("Cuota estandar: $" + cuot);
                        Cumm.setText("Cum del estudiante: " + cumm);
                        Institu.setText("Tipo de institucion proveniente: " + seIn);
                        Total.setText("Cuota estandar mas aumento de 30% de carrera mas $20 por herramientas: $" + total +"\n\nDescuento de 25% por CUM de " + cumm
                                + " : $" + cumDes + "\n\nDescuento de 10% por venir de una institucion Privada: $" + inDes +"\n\nDescuento total: $" + descuentoTotal
                                + "\n\nTotal a pagar: $" + pagoTotal);

                    }

                    //Datos.setText(nomb + " estudias " + seCarre + " la cuota es de " + cuot + " + " + aumento + " de carrera - " + cumDes + " de cum y " + inDes + " de institucion");
                } else if (cumm > 8 && cumm <= 9) {

                    cumDes = total * 0.2;
                    if (seIn.equals("Pública")){
                        inDes = total * 0.05;
                        descuentoTotal = cumDes + inDes;
                        pagoTotal = total - descuentoTotal;

                        Nomb.setText("Nombre del estudiante: " + nomb);
                        Carre.setText("Carrera seleccionada: " + seCarre);
                        Cuot.setText("Cuota estandar: $" + cuot);
                        Cumm.setText("Cum del estudiante: " + cumm);
                        Institu.setText("Tipo de institucion proveniente: " + seIn);
                        Total.setText("Cuota estandar mas aumento de 30% de carrera mas $20 por herramientas: $" + total +"\n\nDescuento de 20% por CUM de " + cumm
                                + " : $" + cumDes + "\n\nDescuento de 5% por venir de una institucion Pública: $" + inDes +"\n\nDescuento total: $" + descuentoTotal
                                + "\n\nTotal a pagar: $" + pagoTotal);

                    } else if (seIn.equals("Privada")) {
                        inDes = total * 0.1;
                        descuentoTotal = cumDes + inDes;
                        pagoTotal = total - descuentoTotal;

                        Nomb.setText("Nombre del estudiante: " + nomb);
                        Carre.setText("Carrera seleccionada: " + seCarre);
                        Cuot.setText("Cuota estandar: $" + cuot);
                        Cumm.setText("Cum del estudiante: " + cumm);
                        Institu.setText("Tipo de institucion proveniente: " + seIn);
                        Total.setText("Cuota estandar mas aumento de 30% de carrera mas $20 por herramientas: $" + total +"\n\nDescuento de 20% por CUM de " + cumm
                                + " : $" + cumDes + "\n\nDescuento de 10% por venir de una institucion Privada: $" + inDes +"\n\nDescuento total: $" + descuentoTotal
                                + "\n\nTotal a pagar: $" + pagoTotal);

                    }

                } else if (cumm >= 7 && cumm <= 8) {

                    cumDes =total * 0.15;
                    if (seIn.equals("Pública")){
                        inDes = total * 0.05;
                        descuentoTotal = cumDes + inDes;
                        pagoTotal = total - descuentoTotal;

                        Nomb.setText("Nombre del estudiante: " + nomb);
                        Carre.setText("Carrera seleccionada: " + seCarre);
                        Cuot.setText("Cuota estandar: $" + cuot);
                        Cumm.setText("Cum del estudiante: " + cumm);
                        Institu.setText("Tipo de institucion proveniente: " + seIn);
                        Total.setText("Cuota edtandar mas aumento de 30% de carrera mas $20 por herramientas: $" + total +"\n\nDescuento de 15% por CUM de " + cumm
                                + " : $" + cumDes + "\n\nDescuento de 5% por venir de una institucion Pública: $" + inDes +"\n\nDescuento total: $" + descuentoTotal
                                + "\n\nTotal a pagar: $" + pagoTotal);

                    } else if (seIn.equals("Privada")) {
                        inDes = total * 0.1;
                        descuentoTotal = cumDes + inDes;
                        pagoTotal = total - descuentoTotal;

                        Nomb.setText("Nombre del estudiante: " + nomb);
                        Carre.setText("Carrera seleccionada: " + seCarre);
                        Cuot.setText("Cuota estandar: $" + cuot);
                        Cumm.setText("Cum del estudiante: " + cumm);
                        Institu.setText("Tipo de institucion proveniente: " + seIn);
                        Total.setText("Cuota estandar mas aumento de 30% de carrera mas $20 por herramientas: $" + total +"\n\nDescuento de 15% por CUM de " + cumm
                                + " : $" + cumDes + "\n\nDescuento de 10% por venir de una institucion Privada: $" + inDes +"\n\nDescuento total: $" + descuentoTotal
                                + "\n\nTotal a pagar: $" + pagoTotal);

                    }

                } else if (cumm > 0 && cumm < 7) {

                    cumDes =total * 0;
                    if (seIn.equals("Pública")){
                        inDes = total * 0.05;
                        descuentoTotal = cumDes + inDes;
                        pagoTotal = total - descuentoTotal;

                        Nomb.setText("Nombre del estudiante: " + nomb);
                        Carre.setText("Carrera seleccionada: " + seCarre);
                        Cuot.setText("Cuota estandar: $" + cuot);
                        Cumm.setText("Cum del estudiante: " + cumm);
                        Institu.setText("Tipo de institucion proveniente: " + seIn);
                        Total.setText("Cuota edtandar mas aumento de 30% de carrera mas $20 por herramientas: $" + total +"\n\nNo aplica descuento por CUM de " + cumm
                                + " : $" + cumDes + "\n\nDescuento de 5% por venir de una institucion Pública: $" + inDes +"\n\nDescuento total: $" + descuentoTotal
                                + "\n\nTotal a pagar: $" + pagoTotal);

                    } else if (seIn.equals("Privada")) {
                        inDes = total * 0.1;
                        descuentoTotal = cumDes + inDes;
                        pagoTotal = total - descuentoTotal;

                        Nomb.setText("Nombre del estudiante: " + nomb);
                        Carre.setText("Carrera seleccionada: " + seCarre);
                        Cuot.setText("Cuota estandar: $" + cuot);
                        Cumm.setText("Cum del estudiante: " + cumm);
                        Institu.setText("Tipo de institucion proveniente: " + seIn);
                        Total.setText("Cuota estandar mas aumento de 30% de carrera mas $20 por herramientas: $" + total +"\n\nNo aplica descuento por CUM de " + cumm
                                + " : $" + cumDes + "\n\nDescuento de 10% por venir de una institucion Privada: $" + inDes +"\n\nDescuento total: $" + descuentoTotal
                                + "\n\nTotal a pagar: $" + pagoTotal);

                    }

                }


            } else if (seCarre.equals("Ingenieria en Sistemas")) {
                aumento = (cuot * 0.4) + 25;
                total = cuot + aumento;
                if (cumm > 9 && cumm <= 10){
                    cumDes = total * 0.25;
                    if (seIn.equals("Pública")){
                        inDes = total * 0.05;
                        descuentoTotal = cumDes + inDes;
                        pagoTotal = total - descuentoTotal;

                        Nomb.setText("Nombre del estudiante: " + nomb);
                        Carre.setText("Carrera seleccionada: " + seCarre);
                        Cuot.setText("Cuota estandar: $" + cuot);
                        Cumm.setText("Cum del estudiante: " + cumm);
                        Institu.setText("Tipo de institucion proveniente: " + seIn);
                        Total.setText("Cuota estandar mas aumento de 40% de carrera mas $25 por herramientas: $" + total +"\n\nDescuento de 25% por CUM de " + cumm
                                + " : $" + cumDes + "\n\nDescuento de 5% por venir de una institucion Pública: $" + inDes +"\n\nDescuento total: $" + descuentoTotal
                                + "\n\nTotal a pagar: $" + pagoTotal);

                    } else if (seIn.equals("Privada")) {
                        inDes = total * 0.1;
                        descuentoTotal = cumDes + inDes;
                        pagoTotal = total - descuentoTotal;

                        Nomb.setText("Nombre del estudiante: " + nomb);
                        Carre.setText("Carrera seleccionada: " + seCarre);
                        Cuot.setText("Cuota estandar: $" + cuot);
                        Cumm.setText("Cum del estudiante: " + cumm);
                        Institu.setText("Tipo de institucion proveniente: " + seIn);
                        Total.setText("Cuota estandar mas aumento de 40% de carrera mas $25 por herramientas: $" + total +"\n\nDescuento de 25% por CUM de " + cumm
                                + " : $" + cumDes + "\n\nDescuento de 10% por venir de una institucion Privada: $" + inDes +"\n\nDescuento total: $" + descuentoTotal
                                + "\n\nTotal a pagar: $" + pagoTotal);

                    }

                    //Datos.setText(nomb + " estudias " + seCarre + " la cuota es de " + cuot + " + " + aumento + " de carrera - " + cumDes + " de cum y " + inDes + " de institucion");
                } else if (cumm > 8 && cumm <= 9) {

                    cumDes = total * 0.2;
                    if (seIn.equals("Pública")){
                        inDes = total * 0.05;
                        descuentoTotal = cumDes + inDes;
                        pagoTotal = total - descuentoTotal;

                        Nomb.setText("Nombre del estudiante: " + nomb);
                        Carre.setText("Carrera seleccionada: " + seCarre);
                        Cuot.setText("Cuota estandar: $" + cuot);
                        Cumm.setText("Cum del estudiante: " + cumm);
                        Institu.setText("Tipo de institucion proveniente: " + seIn);
                        Total.setText("Cuota estandar mas aumento de 40% de carrera mas $25 por herramientas: $" + total +"\n\nDescuento de 20% por CUM de " + cumm
                                + " : $" + cumDes + "\n\nDescuento de 5% por venir de una institucion Pública: $" + inDes +"\n\nDescuento total: $" + descuentoTotal
                                + "\n\nTotal a pagar: $" + pagoTotal);

                    } else if (seIn.equals("Privada")) {
                        inDes = total * 0.1;
                        descuentoTotal = cumDes + inDes;
                        pagoTotal = total - descuentoTotal;

                        Nomb.setText("Nombre del estudiante: " + nomb);
                        Carre.setText("Carrera seleccionada: " + seCarre);
                        Cuot.setText("Cuota estandar: $" + cuot);
                        Cumm.setText("Cum del estudiante: " + cumm);
                        Institu.setText("Tipo de institucion proveniente: " + seIn);
                        Total.setText("Cuota estandar mas aumento de 40% de carrera mas $25 por herramientas: $" + total +"\n\nDescuento de 20% por CUM de " + cumm
                                + " : $" + cumDes + "\n\nDescuento de 10% por venir de una institucion Privada: $" + inDes +"\n\nDescuento total: $" + descuentoTotal
                                + "\n\nTotal a pagar: $" + pagoTotal);

                    }

                } else if (cumm >= 7 && cumm <= 8) {

                    cumDes =total * 0.15;
                    if (seIn.equals("Pública")){
                        inDes = total * 0.05;
                        descuentoTotal = cumDes + inDes;
                        pagoTotal = total - descuentoTotal;

                        Nomb.setText("Nombre del estudiante: " + nomb);
                        Carre.setText("Carrera seleccionada: " + seCarre);
                        Cuot.setText("Cuota estandar: $" + cuot);
                        Cumm.setText("Cum del estudiante: " + cumm);
                        Institu.setText("Tipo de institucion proveniente: " + seIn);
                        Total.setText("Cuota estandar mas aumento de 40% de carrera mas $25 por herramientas: $" + total +"\n\nDescuento de 15% por CUM de " + cumm
                                + " : $" + cumDes + "\n\nDescuento de 5% por venir de una institucion Pública: $" + inDes +"\n\nDescuento total: $" + descuentoTotal
                                + "\n\nTotal a pagar: $" + pagoTotal);

                    } else if (seIn.equals("Privada")) {
                        inDes = total * 0.1;
                        descuentoTotal = cumDes + inDes;
                        pagoTotal = total - descuentoTotal;

                        Nomb.setText("Nombre del estudiante: " + nomb);
                        Carre.setText("Carrera seleccionada: " + seCarre);
                        Cuot.setText("Cuota estandar: $" + cuot);
                        Cumm.setText("Cum del estudiante: " + cumm);
                        Institu.setText("Tipo de institucion proveniente: " + seIn);
                        Total.setText("Cuota estandar mas aumento de 40% de carrera mas $25 por herramientas: $" + total +"\n\nDescuento de 15% por CUM de " + cumm
                                + " : $" + cumDes + "\n\nDescuento de 10% por venir de una institucion Privada: $" + inDes +"\n\nDescuento total: $" + descuentoTotal
                                + "\n\nTotal a pagar: $" + pagoTotal);

                    }

                } else if (cumm > 0 && cumm < 7) {

                    cumDes =total * 0;
                    if (seIn.equals("Pública")){
                        inDes = total * 0.05;
                        descuentoTotal = cumDes + inDes;
                        pagoTotal = total - descuentoTotal;

                        Nomb.setText("Nombre del estudiante: " + nomb);
                        Carre.setText("Carrera seleccionada: " + seCarre);
                        Cuot.setText("Cuota estandar: $" + cuot);
                        Cumm.setText("Cum del estudiante: " + cumm);
                        Institu.setText("Tipo de institucion proveniente: " + seIn);
                        Total.setText("Cuota edtandar mas aumento de 40% de carrera mas $25 por herramientas: $" + total +"\n\nNo aplica descuento por CUM de " + cumm
                                + " : $" + cumDes + "\n\nDescuento de 5% por venir de una institucion Pública: $" + inDes +"\n\nDescuento total: $" + descuentoTotal
                                + "\n\nTotal a pagar: $" + pagoTotal);

                    } else if (seIn.equals("Privada")) {
                        inDes = total * 0.1;
                        descuentoTotal = cumDes + inDes;
                        pagoTotal = total - descuentoTotal;

                        Nomb.setText("Nombre del estudiante: " + nomb);
                        Carre.setText("Carrera seleccionada: " + seCarre);
                        Cuot.setText("Cuota estandar: $" + cuot);
                        Cumm.setText("Cum del estudiante: " + cumm);
                        Institu.setText("Tipo de institucion proveniente: " + seIn);
                        Total.setText("Cuota estandar mas aumento de 40% de carrera mas $25 por herramientas: $" + total +"\n\nNo aplica descuento por CUM de " + cumm
                                + " : $" + cumDes + "\n\nDescuento de 10% por venir de una institucion Privada: $" + inDes +"\n\nDescuento total: $" + descuentoTotal
                                + "\n\nTotal a pagar: $" + pagoTotal);

                    }

                }

            } else if (seCarre.equals("Tecnico en Sistemas")) {

                aumento = (cuot * 0.45) + 30;
                total = cuot + aumento;
                if (cumm > 9 && cumm <= 10){
                    cumDes = total * 0.25;
                    if (seIn.equals("Pública")){
                        inDes = total * 0.05;
                        descuentoTotal = cumDes + inDes;
                        pagoTotal = total - descuentoTotal;

                        Nomb.setText("Nombre del estudiante: " + nomb);
                        Carre.setText("Carrera seleccionada: " + seCarre);
                        Cuot.setText("Cuota estandar: $" + cuot);
                        Cumm.setText("Cum del estudiante: " + cumm);
                        Institu.setText("Tipo de institucion proveniente: " + seIn);
                        Total.setText("Cuota estandar mas aumento de 45% de carrera mas $30 por herramientas: $" + total +"\n\nDescuento de 25% por CUM de " + cumm
                                + " : $" + cumDes + "\n\nDescuento de 5% por venir de una institucion Pública: $" + inDes +"\n\nDescuento total: $" + descuentoTotal
                                + "\n\nTotal a pagar: $" + pagoTotal);

                    } else if (seIn.equals("Privada")) {
                        inDes = total * 0.1;
                        descuentoTotal = cumDes + inDes;
                        pagoTotal = total - descuentoTotal;

                        Nomb.setText("Nombre del estudiante: " + nomb);
                        Carre.setText("Carrera seleccionada: " + seCarre);
                        Cuot.setText("Cuota estandar: $" + cuot);
                        Cumm.setText("Cum del estudiante: " + cumm);
                        Institu.setText("Tipo de institucion proveniente: " + seIn);
                        Total.setText("Cuota estandar mas aumento de 45% de carrera mas $30 por herramientas: $" + total +"\n\nDescuento de 25% por CUM de " + cumm
                                + " : $" + cumDes + "\n\nDescuento de 10% por venir de una institucion Privada: $" + inDes +"\n\nDescuento total: $" + descuentoTotal
                                + "\n\nTotal a pagar: $" + pagoTotal);

                    }

                    //Datos.setText(nomb + " estudias " + seCarre + " la cuota es de " + cuot + " + " + aumento + " de carrera - " + cumDes + " de cum y " + inDes + " de institucion");
                } else if (cumm > 8 && cumm <= 9) {

                    cumDes = total * 0.2;
                    if (seIn.equals("Pública")){
                        inDes = total * 0.05;
                        descuentoTotal = cumDes + inDes;
                        pagoTotal = total - descuentoTotal;

                        Nomb.setText("Nombre del estudiante: " + nomb);
                        Carre.setText("Carrera seleccionada: " + seCarre);
                        Cuot.setText("Cuota estandar: $" + cuot);
                        Cumm.setText("Cum del estudiante: " + cumm);
                        Institu.setText("Tipo de institucion proveniente: " + seIn);
                        Total.setText("Cuota estandar mas aumento de 45% de carrera mas $30 por herramientas: $" + total +"\n\nDescuento de 20% por CUM de " + cumm
                                + " : $" + cumDes + "\n\nDescuento de 5% por venir de una institucion Pública: $" + inDes +"\n\nDescuento total: $" + descuentoTotal
                                + "\n\nTotal a pagar: $" + pagoTotal);

                    } else if (seIn.equals("Privada")) {
                        inDes = total * 0.1;
                        descuentoTotal = cumDes + inDes;
                        pagoTotal = total - descuentoTotal;

                        Nomb.setText("Nombre del estudiante: " + nomb);
                        Carre.setText("Carrera seleccionada: " + seCarre);
                        Cuot.setText("Cuota estandar: $" + cuot);
                        Cumm.setText("Cum del estudiante: " + cumm);
                        Institu.setText("Tipo de institucion proveniente: " + seIn);
                        Total.setText("Cuota estandar mas aumento de 45% de carrera mas $30 por herramientas: $" + total +"\n\nDescuento de 20% por CUM de " + cumm
                                + " : $" + cumDes + "\n\nDescuento de 10% por venir de una institucion Privada: $" + inDes +"\n\nDescuento total: $" + descuentoTotal
                                + "\n\nTotal a pagar: $" + pagoTotal);

                    }

                } else if (cumm >= 7 && cumm <= 8) {

                    cumDes =total * 0.15;
                    if (seIn.equals("Pública")){
                        inDes = total * 0.05;
                        descuentoTotal = cumDes + inDes;
                        pagoTotal = total - descuentoTotal;

                        Nomb.setText("Nombre del estudiante: " + nomb);
                        Carre.setText("Carrera seleccionada: " + seCarre);
                        Cuot.setText("Cuota estandar: $" + cuot);
                        Cumm.setText("Cum del estudiante: " + cumm);
                        Institu.setText("Tipo de institucion proveniente: " + seIn);
                        Total.setText("Cuota estandar mas aumento de 45% de carrera mas $30 por herramientas: $" + total +"\n\nDescuento de 15% por CUM de " + cumm
                                + " : $" + cumDes + "\n\nDescuento de 5% por venir de una institucion Pública: $" + inDes +"\n\nDescuento total: $" + descuentoTotal
                                + "\n\nTotal a pagar: $" + pagoTotal);

                    } else if (seIn.equals("Privada")) {
                        inDes = total * 0.1;
                        descuentoTotal = cumDes + inDes;
                        pagoTotal = total - descuentoTotal;

                        Nomb.setText("Nombre del estudiante: " + nomb);
                        Carre.setText("Carrera seleccionada: " + seCarre);
                        Cuot.setText("Cuota estandar: $" + cuot);
                        Cumm.setText("Cum del estudiante: " + cumm);
                        Institu.setText("Tipo de institucion proveniente: " + seIn);
                        Total.setText("Cuota estandar mas aumento de 45% de carrera mas $30 por herramientas: $" + total +"\n\nDescuento de 15% por CUM de " + cumm
                                + " : $" + cumDes + "\n\nDescuento de 10% por venir de una institucion Privada: $" + inDes +"\n\nDescuento total: $" + descuentoTotal
                                + "\n\nTotal a pagar: $" + pagoTotal);

                    }

                } else if (cumm > 0 && cumm < 7) {

                    cumDes =total * 0;
                    if (seIn.equals("Pública")){
                        inDes = total * 0.05;
                        descuentoTotal = cumDes + inDes;
                        pagoTotal = total - descuentoTotal;

                        Nomb.setText("Nombre del estudiante: " + nomb);
                        Carre.setText("Carrera seleccionada: " + seCarre);
                        Cuot.setText("Cuota estandar: $" + cuot);
                        Cumm.setText("Cum del estudiante: " + cumm);
                        Institu.setText("Tipo de institucion proveniente: " + seIn);
                        Total.setText("Cuota edtandar mas aumento de 45% de carrera mas $30 por herramientas: $" + total +"\n\nNo aplica descuento por CUM de " + cumm
                                + " : $" + cumDes + "\n\nDescuento de 5% por venir de una institucion Pública: $" + inDes +"\n\nDescuento total: $" + descuentoTotal
                                + "\n\nTotal a pagar: $" + pagoTotal);

                    } else if (seIn.equals("Privada")) {
                        inDes = total * 0.1;
                        descuentoTotal = cumDes + inDes;
                        pagoTotal = total - descuentoTotal;

                        Nomb.setText("Nombre del estudiante: " + nomb);
                        Carre.setText("Carrera seleccionada: " + seCarre);
                        Cuot.setText("Cuota estandar: $" + cuot);
                        Cumm.setText("Cum del estudiante: " + cumm);
                        Institu.setText("Tipo de institucion proveniente: " + seIn);
                        Total.setText("Cuota estandar mas aumento de 45% de carrera mas $30 por herramientas: $" + total +"\n\nNo aplica descuento por CUM de " + cumm
                                + " : $" + cumDes + "\n\nDescuento de 10% por venir de una institucion Privada: $" + inDes +"\n\nDescuento total: $" + descuentoTotal
                                + "\n\nTotal a pagar: $" + pagoTotal);

                    }

                }
            }


        }
    }
}