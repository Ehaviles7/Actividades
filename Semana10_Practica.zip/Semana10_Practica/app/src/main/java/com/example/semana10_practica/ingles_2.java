package com.example.semana10_practica;

import androidx.appcompat.app.AppCompatActivity;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

public class ingles_2 extends AppCompatActivity {

    //Declarar los objetos
    ImageView Lion, Elephant, Dog, Cat, Fish, Octopus, Cow, Monkey, Whale, Tiger, Atras;
    MediaPlayer reproductor;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ingles2);
        //Referenciar los objetos
        Lion = findViewById(R.id.imgLion);
        Elephant = findViewById(R.id.imElephant);
        Dog = findViewById(R.id.imDog);
        Cat = findViewById(R.id.imCat);
        Fish = findViewById(R.id.imFish);
        Octopus = findViewById(R.id.imOctopus);
        Cow = findViewById(R.id.imCow);
        Monkey = findViewById(R.id.imMonkey);
        Whale = findViewById(R.id.imWhale);
        Tiger = findViewById(R.id.imTiger);
        Atras = findViewById(R.id.imAtras);

        Toast.makeText(this, "Touch the animals and hear their names", Toast.LENGTH_LONG).show();

        //Establecer los eventos click

        Lion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    if (reproductor != null){
                        if (reproductor.isPlaying()){
                            reproductor.release();
                            reproductor = null;
                        }
                    }

                    reproductor = MediaPlayer.create(ingles_2.this, R.raw.lion);
                    reproductor.start();
                }catch (Exception e){
                    Log.e("Error", e.getMessage());
                }
            }
        });

        Elephant.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    if (reproductor != null){
                        if (reproductor.isPlaying()){
                            reproductor.release();
                            reproductor = null;
                        }
                    }

                    reproductor = MediaPlayer.create(ingles_2.this, R.raw.elephant);
                    reproductor.start();
                }catch (Exception e){
                    Log.e("Error", e.getMessage());
                }
            }
        });

        Dog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    if (reproductor != null){
                        if (reproductor.isPlaying()){
                            reproductor.release();
                            reproductor = null;
                        }
                    }

                    reproductor = MediaPlayer.create(ingles_2.this, R.raw.dog);
                    reproductor.start();
                }catch (Exception e){
                    Log.e("Error", e.getMessage());
                }
            }
        });

        Cat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    if (reproductor != null){
                        if (reproductor.isPlaying()){
                            reproductor.release();
                            reproductor = null;
                        }
                    }

                    reproductor = MediaPlayer.create(ingles_2.this, R.raw.cat);
                    reproductor.start();
                }catch (Exception e){
                    Log.e("Error", e.getMessage());
                }
            }
        });

        Fish.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    if (reproductor != null){
                        if (reproductor.isPlaying()){
                            reproductor.release();
                            reproductor = null;
                        }
                    }

                    reproductor = MediaPlayer.create(ingles_2.this, R.raw.fish);
                    reproductor.start();
                }catch (Exception e){
                    Log.e("Error", e.getMessage());
                }
            }
        });

        Octopus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    if (reproductor != null){
                        if (reproductor.isPlaying()){
                            reproductor.release();
                            reproductor = null;
                        }
                    }

                    reproductor = MediaPlayer.create(ingles_2.this, R.raw.octopus);
                    reproductor.start();
                }catch (Exception e){
                    Log.e("Error", e.getMessage());
                }
            }
        });

        Cow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    if (reproductor != null){
                        if (reproductor.isPlaying()){
                            reproductor.release();
                            reproductor = null;
                        }
                    }

                    reproductor = MediaPlayer.create(ingles_2.this, R.raw.cow);
                    reproductor.start();
                }catch (Exception e){
                    Log.e("Error", e.getMessage());
                }
            }
        });

        Monkey.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    if (reproductor != null){
                        if (reproductor.isPlaying()){
                            reproductor.release();
                            reproductor = null;
                        }
                    }

                    reproductor = MediaPlayer.create(ingles_2.this, R.raw.monkey);
                    reproductor.start();
                }catch (Exception e){
                    Log.e("Error", e.getMessage());
                }
            }
        });

        Whale.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    if (reproductor != null){
                        if (reproductor.isPlaying()){
                            reproductor.release();
                            reproductor = null;
                        }
                    }

                    reproductor = MediaPlayer.create(ingles_2.this, R.raw.whale);
                    reproductor.start();
                }catch (Exception e){
                    Log.e("Error", e.getMessage());
                }
            }
        });

        Tiger.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    if (reproductor != null){
                        if (reproductor.isPlaying()){
                            reproductor.release();
                            reproductor = null;
                        }
                    }

                    reproductor = MediaPlayer.create(ingles_2.this, R.raw.tiger);
                    reproductor.start();
                }catch (Exception e){
                    Log.e("Error", e.getMessage());
                }
            }
        });
    }

    @Override
    protected void onPause() {
        super.onPause();
        try {
            if (reproductor.isPlaying()){
                reproductor.release();
                reproductor = null;
            }

        }catch (Exception e){
            Log.e("Error", e.getMessage());
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        Atras.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        try {
            if (reproductor.isPlaying()){
                reproductor.release();
                reproductor = null;
            }

        }catch (Exception e){
            Log.e("Error", e.getMessage());
        }
    }
}