package com.example.semana10_practica;

import androidx.appcompat.app.AppCompatActivity;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

public class espa_2 extends AppCompatActivity {
    //Declarar los objetos

    ImageView Leon, Elefante, Perro, Gato, Pez, Pulpo, Vaca, Mono, Ballena, Tigre, Retornar;

    MediaPlayer reproductor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_espa2);
        //Establecer las referencias

        Leon = findViewById(R.id.imLeon);
        Elefante = findViewById(R.id.imElefante);
        Perro = findViewById(R.id.imPerro);
        Gato = findViewById(R.id.imGato);
        Pez = findViewById(R.id.imPez);
        Pulpo = findViewById(R.id.imPulpo);
        Vaca = findViewById(R.id.imVaca);
        Mono = findViewById(R.id.imMono);
        Ballena = findViewById(R.id.imBallena);
        Tigre = findViewById(R.id.imTigre);
        Retornar = findViewById(R.id.imRetornar);

        Toast.makeText(this, "Toca los animales y escucha sus nombres", Toast.LENGTH_LONG).show();

        //Establecemos los eventos click

        Leon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    if (reproductor != null){
                        if (reproductor.isPlaying()){
                            reproductor.release();
                            reproductor = null;
                        }
                    }

                    reproductor = MediaPlayer.create(espa_2.this, R.raw.leon);
                    reproductor.start();
                }catch (Exception e){
                    Log.e("Error", e.getMessage());
                }
            }
        });

        Elefante.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    if (reproductor != null){
                        if (reproductor.isPlaying()){
                            reproductor.release();
                            reproductor = null;
                        }
                    }

                    reproductor = MediaPlayer.create(espa_2.this, R.raw.elefante);
                    reproductor.start();
                }catch (Exception e){
                    Log.e("Error", e.getMessage());
                }
            }
        });

        Perro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    if (reproductor != null){
                        if (reproductor.isPlaying()){
                            reproductor.release();
                            reproductor = null;
                        }
                    }

                    reproductor = MediaPlayer.create(espa_2.this, R.raw.perro);
                    reproductor.start();
                }catch (Exception e){
                    Log.e("Error", e.getMessage());
                }
            }
        });

        Gato.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    if (reproductor != null){
                        if (reproductor.isPlaying()){
                            reproductor.release();
                            reproductor = null;
                        }
                    }

                    reproductor = MediaPlayer.create(espa_2.this, R.raw.gato);
                    reproductor.start();
                }catch (Exception e){
                    Log.e("Error", e.getMessage());
                }
            }
        });

        Pez.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    if (reproductor != null){
                        if (reproductor.isPlaying()){
                            reproductor.release();
                            reproductor = null;
                        }
                    }

                    reproductor = MediaPlayer.create(espa_2.this, R.raw.pez);
                    reproductor.start();
                }catch (Exception e){
                    Log.e("Error", e.getMessage());
                }
            }
        });

        Pulpo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    if (reproductor != null){
                        if (reproductor.isPlaying()){
                            reproductor.release();
                            reproductor = null;
                        }
                    }

                    reproductor = MediaPlayer.create(espa_2.this, R.raw.pulpo);
                    reproductor.start();
                }catch (Exception e){
                    Log.e("Error", e.getMessage());
                }
            }
        });

        Vaca.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    if (reproductor != null){
                        if (reproductor.isPlaying()){
                            reproductor.release();
                            reproductor = null;
                        }
                    }

                    reproductor = MediaPlayer.create(espa_2.this, R.raw.vaca);
                    reproductor.start();
                }catch (Exception e){
                    Log.e("Error", e.getMessage());
                }
            }
        });

        Mono.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    if (reproductor != null){
                        if (reproductor.isPlaying()){
                            reproductor.release();
                            reproductor = null;
                        }
                    }

                    reproductor = MediaPlayer.create(espa_2.this, R.raw.mono);
                    reproductor.start();
                }catch (Exception e){
                    Log.e("Error", e.getMessage());
                }
            }
        });

        Ballena.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    if (reproductor != null){
                        if (reproductor.isPlaying()){
                            reproductor.release();
                            reproductor = null;
                        }
                    }

                    reproductor = MediaPlayer.create(espa_2.this, R.raw.ballena);
                    reproductor.start();
                }catch (Exception e){
                    Log.e("Error", e.getMessage());
                }
            }
        });

        Tigre.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    if (reproductor != null){
                        if (reproductor.isPlaying()){
                            reproductor.release();
                            reproductor = null;
                        }
                    }

                    reproductor = MediaPlayer.create(espa_2.this, R.raw.tigre);
                    reproductor.start();
                }catch (Exception e){
                    Log.e("Error", e.getMessage());
                }
            }
        });
    }

    @Override
    protected void onPause() {
        super.onPause();
        try {
            if (reproductor.isPlaying()){
                reproductor.release();
                reproductor = null;
            }
        }catch (Exception e){
            Log.e("Error", e.getMessage());
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        Retornar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        try {
            if (reproductor.isPlaying()){
                reproductor.release();
                reproductor = null;
            }
        }catch (Exception e){
            Log.e("Error", e.getMessage());
        }
    }
}