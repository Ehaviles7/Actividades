package com.example.practica_7;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    //Declaramos los objetos en la clase
    Button Proximidad, Luminosidad;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Referenciamos los objetos
        Proximidad = findViewById(R.id.btProxi);
        Luminosidad = findViewById(R.id.btLumi);

        Proximidad.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                irProximidad();
            }
        });

        Luminosidad.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                irLuminosidad();
            }
        });
    }

    public void irProximidad(){
        Intent nuevaProxi = new Intent(MainActivity.this, datosProxi2.class);
        startActivity(nuevaProxi);
    }

    public void irLuminosidad(){
        Intent nuevaLumi = new Intent(MainActivity.this, datosLumi2.class);
        startActivity(nuevaLumi);
    }
}