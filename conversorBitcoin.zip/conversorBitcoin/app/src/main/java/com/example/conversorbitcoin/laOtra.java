package com.example.conversorbitcoin;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class laOtra extends AppCompatActivity {

    //Definir los objetos en la clase
    TextView Mostrar;
    Button Regre;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_la_otra);

        //Referenciar los objetos en la clase

        Mostrar = findViewById(R.id.tvMostrar);
        Regre = findViewById(R.id.btRegre);

        //Configurar evento
        Regre.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                pro();
            }
        });

        }

        public  void pro(){
        finish();
        }

    @Override
    protected void onResume() {
        super.onResume();
        Bundle hayDatos = getIntent().getExtras();
        if (hayDatos != null){
            String per = hayDatos.getString("Pera");

        }

    }
}