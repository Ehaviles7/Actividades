package com.example.datospersonales;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    //Declarar los objetos en la clase

    EditText Nombre, Cuota, Cum;
    Button Saludar;
    Spinner Carrera, Institucion;

    String[] listaCarrera = {"Ingenieria en Manejo y Gestion de Base de Datos", "Ingenieria en Sistemas", "Tecnico en Sistemas"};

    String[] listaInstitucion = {"Pública", "Privada"};
    //Spinner Mes;

    //String[] listaMes = {"Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Referenciar los objetos

        Nombre = findViewById(R.id.etNombre);
        Cuota = findViewById(R.id.etCuota);
        Cum = findViewById(R.id.etCum);
        Carrera = findViewById(R.id.spCarrera);
        Institucion = findViewById(R.id.spInstitucion);
        //Apellido = findViewById(R.id.etApellido);
        //Edad = findViewById(R.id.etEdad);
        Saludar = findViewById(R.id.btSaludar);
        //Mes = findViewById(R.id.spMes);

        //ArrayAdapter<String> opcionMes = new ArrayAdapter<String>(this, androidx.appcompat.R.layout.support_simple_spinner_dropdown_item, listaMes);
        //Mes.setAdapter(opcionMes);
        ArrayAdapter<String> opcionCarrera = new ArrayAdapter<String>(this, androidx.appcompat.R.layout.support_simple_spinner_dropdown_item, listaCarrera);
        Carrera.setAdapter(opcionCarrera);
        ArrayAdapter<String> opcionInstitucion = new ArrayAdapter<String>(this, androidx.appcompat.R.layout.support_simple_spinner_dropdown_item, listaInstitucion);
        Institucion.setAdapter(opcionInstitucion);

        Saludar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                salu();
            }
        });

    }

    public void salu(){
        try {
            double cuota = 0;
            double cum = 0;
            String nom, selectCarre, selectInstitu;
            nom = Nombre.getText().toString();
            selectCarre = Carrera.getSelectedItem().toString();
            selectInstitu = Institucion.getSelectedItem().toString();


            if (Cuota.getText().toString().equals("")){
                Toast.makeText(this,"Digite bien los valores", Toast.LENGTH_LONG).show();
            }
            else {

                cuota = Double.parseDouble(Cuota.getText().toString());
                cum = Double.parseDouble(Cum.getText().toString());

                Intent Otra = new Intent(MainActivity.this, datos2.class);
                Otra.putExtra("No", nom);
                Otra.putExtra("Cuo", cuota);
                Otra.putExtra("Cu", cum);
                Otra.putExtra("Carr", selectCarre);
                Otra.putExtra("Ins", selectInstitu);
                startActivity(Otra);
            }
        }catch (Exception error){
            Log.e("MainActivity", error.getMessage());
        }
    }
}