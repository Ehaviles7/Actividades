package com.example.usode_imagenes;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import com.squareup.picasso.Picasso;

import jp.wasabeef.picasso.transformations.CropCircleTransformation;
import jp.wasabeef.picasso.transformations.gpu.SepiaFilterTransformation;

public class MainActivity extends AppCompatActivity {

    //Declaramos los objetos

    ImageView Imagen1;

    Button bt1, bt2, bt3, btExterna;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //Referenciar los objetos

        Imagen1 = findViewById(R.id.imImagen);
        bt1 = findViewById(R.id.btImagen1);
        bt2 = findViewById(R.id.btImagen2);
        bt3 = findViewById(R.id.btImagen3);
        btExterna = findViewById(R.id.btImagenExterna);

        bt1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Picasso.get().load(R.drawable.federico).into(Imagen1);

            }
        });

        bt2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Picasso.get()
                        .load(R.drawable.coati)
                        .resize(512,512)
                        .centerCrop()
                        .into(Imagen1);

            }
        });

        bt3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Picasso.get()
                        .load(R.drawable.juliet)
                        .into(Imagen1);

            }
        });

        btExterna.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String URL = "https://w7.pngwing.com/pngs/790/174/png-transparent-giant-anteater-pantanal-sloth-southern-tamandua-anteater-mammal-carnivoran-photography.png";
                Picasso.get()
                        .load(URL)
                        .transform(new CropCircleTransformation())
                        .into(Imagen1);

            }
        });
    }
}