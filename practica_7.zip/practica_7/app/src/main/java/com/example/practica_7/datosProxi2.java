package com.example.practica_7;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class datosProxi2 extends AppCompatActivity {

    //Declaramos objetos en la clase

    Sensor proxiSensor;

    SensorManager admiSensor;

    SensorEventListener escuchaSensor;

    Button Valor;
    ConstraintLayout Colorin;

    TextView Fondo, Senso;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_datos_proxi2);

        //Referenciamos los objetos
        Valor = findViewById(R.id.btValor);
        Colorin = findViewById(R.id.clColor);
        Fondo = findViewById(R.id.tvFondo);
        Senso = findViewById(R.id.tvSensor);

        //Inicializar los servicios del sensor
        admiSensor = (SensorManager) getSystemService(SENSOR_SERVICE);

        //Definir el sensor a utilizar
        proxiSensor = admiSensor.getDefaultSensor(Sensor.TYPE_PROXIMITY);

        //Validacion del sensor;
        if (proxiSensor == null){
            Toast.makeText(datosProxi2.this,"No se detecto el sensor de proximidad", Toast.LENGTH_LONG).show();
        }else {
            Toast.makeText(datosProxi2.this, "Se detecto el sensor de proximidad", Toast.LENGTH_LONG).show();
        }

        //Condigurando el disparador de eventos
        escuchaSensor = new SensorEventListener() {
            @Override
            public void onSensorChanged(SensorEvent sensorEvent) {
                if (sensorEvent.values[0] < proxiSensor.getMaximumRange()){
                    Senso.setTextColor(Color.BLACK);
                    Valor.setText("VALOR: " + sensorEvent.values[0]);
                    Valor.setTextColor(Color.BLACK);
                    Fondo.setBackgroundColor(Color.YELLOW);

                }else {
                    Valor.setText("VALOR: " + sensorEvent.values[0]);
                    Senso.setTextColor(Color.RED);
                    Fondo.setBackgroundColor(Color.WHITE);
                    Valor.setTextColor(Color.RED);

                }
            }

            @Override
            public void onAccuracyChanged(Sensor sensor, int i) {

            }
        };

        inicializarSensor();
    }

    public void inicializarSensor(){
        admiSensor.registerListener(escuchaSensor,proxiSensor,1000*1000);
    }

    public void finalSensor(){
        admiSensor.unregisterListener(escuchaSensor);
    }

    @Override
    protected void onResume() {
        inicializarSensor();
        super.onResume();
    }

    @Override
    protected void onPause() {
        finalSensor();
        super.onPause();
    }
}