package com.example.conversorbitcoin;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    //Definir los objetos en la clase
    Spinner listaMonedas;
    EditText Moneda, bitValor, Cantidad;
    Button Convertir;

    TextView Total;

    String[] lista = {"Dolar", "Lempira", "Quetzales", "Cordobas", "Colon Costarricense"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Referenciar los objetos

        listaMonedas = findViewById(R.id.spMoneda);
        Moneda = findViewById(R.id.etMoneda);
        bitValor = findViewById(R.id.etBitValor);
        Cantidad = findViewById(R.id.etCanti);
        Convertir = findViewById(R.id.btConver);
        Total = findViewById(R.id.tvTotal);

        ArrayAdapter<String>elAdaptador = new ArrayAdapter<String>(this, androidx.appcompat.R.layout.support_simple_spinner_dropdown_item, lista);
        listaMonedas.setAdapter(elAdaptador);

        //Configurar los eventos
        Convertir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                con();
            }
        });

    }

    public void con(){
        try {

            float dolar = 0;
            float lempira =0;
            float quetzal = 0;
            float cordoba = 0;
            float colon = 0;
            float bit = 0;
            float canti = 0;
            float total = 0;
            String conver;
            String opcionSeleccionada;
            opcionSeleccionada = listaMonedas.getSelectedItem().toString();
            if (opcionSeleccionada == "Dolar"){



                dolar = Float.parseFloat(Moneda.getText().toString());
                bit = Float.parseFloat(bitValor.getText().toString());
                canti = Float.parseFloat(Cantidad.getText().toString());
                total = (bit * dolar) * canti;


                Total.setText(bit + " bitcoin equivalen a " + total + " dolares");

            } else if (opcionSeleccionada == "Lempira") {
                lempira = Float.parseFloat(Moneda.getText().toString());
                bit = Float.parseFloat(bitValor.getText().toString());
                canti = Float.parseFloat(Cantidad.getText().toString());
                total = (bit * lempira) * canti;

                Total.setText(bit + " bitcoins equivale a " + total + " lempiras");

            } else if (opcionSeleccionada =="Quetzales") {
                quetzal = Float.parseFloat(Moneda.getText().toString());
                bit = Float.parseFloat(bitValor.getText().toString());
                canti = Float.parseFloat(Cantidad.getText().toString());
                total = (bit * quetzal) * canti;

                Total.setText(bit +" bitcoins esquivalen a " + total + " quetzales");

            } else if (opcionSeleccionada == "Cordobas") {
                cordoba = Float.parseFloat(Moneda.getText().toString());
                bit = Float.parseFloat(bitValor.getText().toString());
                canti = Float.parseFloat(Cantidad.getText().toString());
                total = (bit * cordoba) * canti;

                Total.setText(bit +" bitcoins esquivalen a " + total + " cordobas");

            } else if (opcionSeleccionada == "Colon Costarricense") {
                colon = Float.parseFloat(Moneda.getText().toString());
                bit = Float.parseFloat(bitValor.getText().toString());
                canti = Float.parseFloat(Cantidad.getText().toString());
                total = (bit * colon) * canti;

                Total.setText(bit +" bitcoins esquivalen a " + total + " colones costarricenses");

            }



        }catch (Exception erro){
            Log.e("MainActivity", erro.getMessage());
        }
    }
}