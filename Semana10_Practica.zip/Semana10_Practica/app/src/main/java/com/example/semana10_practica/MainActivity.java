package com.example.semana10_practica;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {

    ImageView Ingles, Espanol;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Ingles = findViewById(R.id.imIngles);
        Espanol = findViewById(R.id.imEspa);

        Ingles.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent ing = new Intent(MainActivity.this, ingles_2.class);
                startActivity(ing);
            }
        });

        Espanol.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent espa = new Intent(MainActivity.this, espa_2.class);
                startActivity(espa);
            }
        });
    }
}